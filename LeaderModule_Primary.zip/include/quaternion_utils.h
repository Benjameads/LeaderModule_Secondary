#ifndef QUATERNION_UTILS_H
#define QUATERNION_UTILS_H

void quaternion_to_euler(const float q[4], float* yaw, float* pitch, float* roll);

#endif
