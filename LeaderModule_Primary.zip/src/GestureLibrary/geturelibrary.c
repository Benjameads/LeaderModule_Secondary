#include <stdio.h>
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"
#include "gesturelibrary.h"
#include "orientation_task.h"
#include "imu_read.h"
#include "imu_spi.h"

void gesture_worker_task(void* arg) {
    GestureOrientationData* gesture_data = NULL;
    GestureState disperse_state; // Initialize the gesture state

    while (1) {
        if(xQueueReceive(gestureQueue, &gesture_data, portMAX_DELAY) != pdTRUE) {
            ESP_LOGE(TAG, "Failed to receive gesture data from queue");
        }

        // Call the gesture functions to process the gesture data
        disperse_state = disperse(gesture_data);
    }
}

float wrap_angle_deg(float angle) {
    while (angle <= -180.0f) angle += 360.0f;
    while (angle > 180.0f) angle -= 360.0f;
    return angle;
}

float shortest_angle_diff(float a, float b) {
    float diff = wrap_angle_deg(a - b);
    return diff;
}
